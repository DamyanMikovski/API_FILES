﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleBooksAPI.Models
{
    public class CreateOrderModel
    {
        [JsonProperty("created")]
        public bool created { get; set; }
        [JsonProperty("orderId")]
        public string orderId { get; set; }
    }
}
