﻿using AventStack.ExtentReports;
using Newtonsoft.Json;
using RestSharp;
using SimpleBooksAPI.Utils;
using SimpleBooksAPI.Models;


namespace SimpleBooksAPI.RequestHelper 
{
    public class ExampleActions 
    {
        private static RestClient restClient = BasеActions.NewRestClient();
        public static string url;
        private ExtentTest test;
        public ExampleActions(ExtentTest test)
        {
            this.test = test;
        }
    }
}
 
