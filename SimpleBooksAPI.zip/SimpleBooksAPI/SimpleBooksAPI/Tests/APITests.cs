﻿using AventStack.ExtentReports;
using FluentAssertions;
using NUnit.Framework;
using SimpleBooksAPI.Utils;
using SimpleBooksAPI.RequestHelper;
using RestSharp;
using Newtonsoft.Json;
using SimpleBooksAPI.Models;
using System.Net;

namespace SimpleBooksAPI.Tests
{
    public class APITests : Base
    {
        [Test]
        public async Task GenerateTokenSucssesfuly()
        {
            var token = await actions.GenerateAccessToken(Properties.authPath);

            try
            {
                test.Log(Status.Pass, "Token is returned successfully");
                token.Should().NotBeNull();
            }

            catch (Exception)
            {
                test.Log(Status.Fail, "Test Fail");
                throw;
            }
        }

        [Test]
        public async Task GetStatus()
        {
            var response = await actions.GetRequest(Properties.booksBaseUrl + Properties.status);

            try
            {
                test.Log(Status.Pass, "Status recived");
                response.Should().NotBeNull();
                response.StatusCode.Should().Be(HttpStatusCode.OK);
            }

            catch (Exception)
            {
                test.Log(Status.Fail, "Test Fail");
                throw;
            }
        }

        [Test]
        public async Task GetAllBooks()
        {
            var response = await actions.GetRequest(Properties.booksBaseUrl + Properties.allBooks);
            var listOfBooks = JsonConvert.DeserializeObject<List<AllBooksIDModel>>(response.Content.ToString());
            var firstBook = listOfBooks[0].bookId;

            try
            {
                test.Log(Status.Pass, response.ToString());
                response.Should().NotBeNull();
                response.StatusCode.Should().Be(HttpStatusCode.OK);
                firstBook.Should().Be(1);
            }
            catch (Exception)
            {
                test.Log(Status.Fail, response.ToString());
                throw;
            }
        }

        [Test]
        public async Task GetSingleBookByID()
        {
            int id = 1;
            var request = await actions.GetRequest(Properties.booksBaseUrl + Properties.singleBook + id.ToString());
            request.StatusCode.Should().Be(HttpStatusCode.OK);
            var response = JsonConvert.DeserializeObject<SingleBookModel>(request.Content.ToString());

            try
            {
                test.Log(Status.Pass, "Retrieving book information");
                response.id.Should().Be(1);
                response.name.Should().Be("The Russian");
            }
            catch (Exception)
            {

                test.Log(Status.Fail, "Test Fail");
                throw;
            }
        }

        [Test]
        public async Task PostOrder()
        {
            var token = await actions.GenerateAccessToken(Properties.authPath);

            RestRequest request = new(Properties.booksBaseUrl + Properties.orders, Method.Post);
            request.AddHeader("Authorization", token);
            request.AddJsonBody(new NewOrderModel
            {
                bookId = 5,
                customerName = "Jon Snow"
            });
            RestResponse orderResponse = await restClient.ExecutePostAsync(request);
            CreateOrderModel jsonBody = JsonConvert.DeserializeObject<CreateOrderModel>(orderResponse.Content.ToString());

            try
            {
                test.Log(Status.Pass, "New Order");
                orderResponse.StatusCode.Should().Be(HttpStatusCode.Created);
                jsonBody.created.Should().Be(true);
                jsonBody.orderId.Should().BeOfType<string>();
            }
            catch (Exception)
            {

                test.Log(Status.Fail, "Test Fail");
                throw;
            }
        }

        [Test]
        public async Task GetAllOrders()
        {
            NewOrderModel newOrder = new NewOrderModel
            {
                bookId = 3,
                customerName = "Damyan"
            };

            var token = await actions.GenerateAccessToken(Properties.authPath);

            RestRequest createOrderRequest = new(Properties.booksBaseUrl + Properties.orders, Method.Post);
            createOrderRequest.AddHeader("Authorization", token);
            createOrderRequest.AddJsonBody(newOrder);
            RestResponse orderResponse = await restClient.ExecutePostAsync(createOrderRequest);
            orderResponse.StatusCode.Should().Be(HttpStatusCode.Created);

            RestRequest getOrderRequest = new(Properties.booksBaseUrl + Properties.orders, Method.Get);
            getOrderRequest.AddHeader("Authorization", token);

            RestResponse response = await restClient.ExecuteGetAsync(getOrderRequest);
            var listOfOrders = JsonConvert.DeserializeObject<List<OrderModel>>(response.Content.ToString());

            try
            {
                foreach (var item in listOfOrders)
                {
                    item.Should().NotBeNull();
                    item.customerName.Should().Be("Damyan");
                }
            }
            catch (Exception)
            {
                test.Log(Status.Fail, response.ToString());
                throw;
            }
        }

        [Test]
        public async Task UpdateOrder()
        {
            var token = await actions.GenerateAccessToken(Properties.authPath);
            RestRequest updateOrderRequest = new(Properties.booksBaseUrl + Properties.orders + , Method.Patch);
            updateOrderRequest.AddHeader("Authorization", token);
            updateOrderRequest.AddJsonBody(new)


        }
    }
}
