﻿using Newtonsoft.Json;

namespace SimpleBooksAPI.Models
{
    public class AllBooksIDModel
    {
        [JsonProperty("id")]
        public int bookId { get; set; }
        [JsonProperty("name")]
        public string name { get; set; }
        [JsonProperty("type")]
        public string type{ get; set; }
        [JsonProperty("available")]
        public string available { get; set; }
    }
}
