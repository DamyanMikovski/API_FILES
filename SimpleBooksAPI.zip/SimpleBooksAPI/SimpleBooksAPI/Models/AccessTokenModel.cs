﻿using Newtonsoft.Json;

namespace SimpleBooksAPI.Models
{

    public class AccessTokenModel
    {
        [JsonProperty("accessToken")]
        public string AccessToken { get; set; }
    }
}
