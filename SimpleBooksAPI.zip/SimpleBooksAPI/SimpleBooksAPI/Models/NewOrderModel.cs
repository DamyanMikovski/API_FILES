﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleBooksAPI.Models
{
    public class NewOrderModel
    {
        [JsonProperty("bookId")]
        public int bookId { get; set; }
        [JsonProperty("customerName")]
        public string customerName { get; set; }
    }
}
