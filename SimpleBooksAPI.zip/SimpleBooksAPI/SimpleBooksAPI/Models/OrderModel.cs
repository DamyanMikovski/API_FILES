﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleBooksAPI.Models
{
    public class OrderModel
    {
        [JsonProperty("id")]
        public string id { get; set; }
        [JsonProperty("bookId")]
        public int bookId { get; set; }
        [JsonProperty("customerName")]
        public string customerName { get; set; }
        [JsonProperty("createdBy")]
        public string createdBy { get; set; }
        [JsonProperty("quantity")]
        public int quantity { get; set; }
        [JsonProperty("timestamp")]
        public long timestamp { get; set; }
    }
}
