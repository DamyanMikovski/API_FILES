﻿
namespace SimpleBooksAPI.Utils
{
    public class Properties
    {
        public const string booksBaseUrl = "https://simple-books-api.glitch.me";
        public const string authPath = "https://simple-books-api.glitch.me/api-clients/";
        public static string userCredentials = "{\"clientName\":\"" + Guid.NewGuid().ToString() + "\",\"clientEmail\":\"" + Guid.NewGuid().ToString() + "@example.com\"}";

        //REPORTER
        public static string projectDirectory = AppContext.BaseDirectory.Substring(0, AppContext.BaseDirectory.IndexOf("bin"));
        public static string reporterFileLocation = projectDirectory + "Reports" + "\\" + DateTime.Now.ToString("_MMddyyyy_hhmmtt") + "\\" + ".html";

        //Endpoints /books/:bookId
        public const string status = "/status";
        public const string allBooks = "/books";
        public const string singleBook = "/books/";
        public const string orders = "/orders";
    }
}