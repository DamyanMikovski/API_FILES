﻿using NUnit.Framework;
using RestSharp;
using SimpleBooksAPI.Utils;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports;
using SimpleBooksAPI.RequestHelper;
using SimpleBooksAPI.Models;

namespace SimpleBooksAPI.Tests
{
    public abstract class Base
    {
        protected ExtentTest test;
        protected ExtentReports extent;
        protected RestClient restClient;
        protected BasеActions actions;
        protected ExampleActions exampleActions;

        [OneTimeSetUp]
        public void OneTimeSetup()
        {
            restClient = BasеActions.NewRestClient();

            extent = new ExtentReports();
            var htmlreporter = new ExtentHtmlReporter(Properties.reporterFileLocation);
            extent.AttachReporter(htmlreporter);
        }

        [SetUp]
        public void SetUp()
        {
            test = extent.CreateTest(TestContext.CurrentContext.Test.Name);
            actions = new BasеActions(test);
            exampleActions = new ExampleActions(test);
        }

        [OneTimeTearDown]
        public void ExtentClose()
        {
            extent.Flush();
        }
    }
}
