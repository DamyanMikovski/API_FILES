﻿using AventStack.ExtentReports;
using Newtonsoft.Json;
using RestSharp;
using SimpleBooksAPI.Models;
using SimpleBooksAPI.Utils;
using SimpleBooksAPI.RequestHelper;
using System.Threading.Tasks;

namespace SimpleBooksAPI.RequestHelper
{
    public class BasеActions
    {
        private static RestClient restClient;
        public static string url;
        private ExtentTest test;

        public BasеActions(ExtentTest test)
        {
            this.test = test;
        }

        public static RestClient NewRestClient()
        {
            restClient = new();
            return restClient;
        }

        public RestRequest NewGetRestRequest(string path)
        {
            RestRequest restRequest = new(path, Method.Get);
            return restRequest;
        }

        public RestRequest AddQueryParameterToGetRequest(string parameterName, string parameterValue, RestRequest restRequest)
        {
            test.Log(Status.Info, "Adding Query Parameters to GET request");

            restRequest.AddParameter(parameterName, parameterValue, ParameterType.QueryString);

            return restRequest;
        }

        public async Task<string> GenerateAccessToken(string url)
        {
            var request = new RestRequest(url, Method.Post);

            request.AddHeader("Content-Type", "application/json");
            request.AddStringBody(Properties.userCredentials, DataFormat.Json);

            var response = await restClient.ExecuteAsync(request);
            AccessTokenModel token = JsonConvert.DeserializeObject<AccessTokenModel>(response.Content.ToString());

            string accessToken = token.AccessToken;

            test.Log(Status.Info, "Received JSon web token");

            return accessToken;
        }

        public async Task<RestResponse> GetRequest(string url)
        {

            var request = new RestRequest(url, Method.Get);

            var response = await restClient.ExecuteAsync(request);

            return response;
        }

        public async Task<RestResponse> AuthGetRequest(string url, string token)
        {

            var request = new RestRequest(url, Method.Get);

            var response = await restClient.ExecuteAsync(request);

            return response;
        }

        public async Task<RestResponse> PostResquest(string url)
        {

            var request = new RestRequest(url, Method.Post);

            var response = await restClient.ExecuteAsync(request);

            return response;
        }

    }
}